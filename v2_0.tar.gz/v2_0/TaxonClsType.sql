INSERT INTO TaxonClsType  (id, code, name)  values  (10001, "EU-ID", "Entity Unit");
INSERT INTO TaxonClsType  (id, code, name)  values  (10002, "OU-ID", "Org Unit");
INSERT INTO TaxonClsType  (id, code, name)  values  (10003, "AU-ID", "Asset Unit");
INSERT INTO TaxonClsType  (id, code, name)  values  (10004, "AT-ID", "Asset Type");
INSERT INTO TaxonClsType  (id, code, name)  values  (10005, "CU-ID", "Component Unit");
INSERT INTO TaxonClsType  (id, code, name)  values  (10006, "G-ID", "Global");
