INSERT INTO ConsentCountryRegion  (id, name, code)  values  (60000, "worldwide", "WW");
INSERT INTO ConsentCountryRegion  (id, name, code)  values  (60001, "United States", "US");
